export class Post {}
