export class CreatePostDto {}
